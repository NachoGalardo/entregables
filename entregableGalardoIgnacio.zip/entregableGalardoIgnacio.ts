/*Pseudocódigo
Ingresar 1 numero por pantalla
Evaluar si es par, impar o cero
Mostrar en pantalla "El numero x es par";"El número x es impar";"El número ingresado es 0"
*/

import * as readlineSync from "readline-sync";
let numero : number = readlineSync.questionInt ("Ingrese su numero: ");

if (numero === 0){
    console.log ("El numero ingresado es 0");
     }else if (numero % 2 === 0) {
     console.log("El numero " + numero +" es par");
            }else{
             console.log("El numero " + numero + " es impar");
            }
