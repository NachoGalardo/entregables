"use strict";

const btnOcultar1 = document.getElementById('btnOcultar1');
const btnOcultar2 = document.getElementById('btnOcultar2');
const div1 = document.querySelector('.div1');
const div2 = document.querySelector('.div2');

btnOcultar1.addEventListener('click', function() {
  div1.style.visibility = 'hidden';
  div2.style.visibility = 'visible';
});

btnOcultar2.addEventListener('click', function() {
  div2.style.visibility = 'hidden';
  div1.style.visibility = 'visible';
});
